import React, { useState } from 'react';
import PropTypes from 'prop-types';

type CalendarProps = {
  date: Date;
};

const Calendar: React.FC<CalendarProps> = ({ date }) => {
  const [currentDate, setCurrentDate] = useState(date);

  const weekdays: string[] = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const month: string = currentDate.toLocaleString('default', { month: 'long' });
  const year: number = currentDate.getFullYear();
  const daysInMonth: number = new Date(year, currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth: number = new Date(year, currentDate.getMonth(), 1).getDay();

  const days: number[] = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  return (
    <div>
      <div className='text-[22px] flex justify-between'>
        <button className='rounded-sm bg-white text-black mr-4 text-sm px-3 py-1' onClick={handlePrevMonth}>Prev</button>
        {month} {year}
        <button className='rounded-sm bg-white text-black ml-4 text-sm px-3 py-1' onClick={handleNextMonth}>Next</button>
      </div>
      <table cellSpacing={15} cellPadding={15}>
        <thead>
          <tr>
            {weekdays.map((weekday: string) => (
              <th className='text-[22px] font-normal' key={weekday}>{weekday}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {Array.from({ length: Math.ceil((firstDayOfMonth + daysInMonth) / 7) }, (_, rowIndex) => (
            <tr key={rowIndex}>
              {Array.from({ length: 7 }, (_, columnIndex) => {
                const dayOfMonth: number = rowIndex * 7 + columnIndex + 1 - firstDayOfMonth;
                const isCurrentMonth: boolean = dayOfMonth >= 1 && dayOfMonth <= daysInMonth;
                const isCurrentDate: boolean =
                  isCurrentMonth && dayOfMonth === currentDate.getDate();

                return (
                  <td
                    key={`${rowIndex}-${columnIndex}`}
                    className={isCurrentDate ? 'font-bold bg-white text-black text-[22px]' : 'font-normal text-[22px]'}
                  >
                    {isCurrentMonth && dayOfMonth}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

Calendar.propTypes = {
  date: PropTypes.instanceOf(Date).isRequired,
};

export default Calendar;
